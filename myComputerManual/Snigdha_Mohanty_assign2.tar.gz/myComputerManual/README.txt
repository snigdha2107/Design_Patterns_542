This is Assignment 2 Factory Pattern & Singleton Pattern











SAMPLE OUTPUT:
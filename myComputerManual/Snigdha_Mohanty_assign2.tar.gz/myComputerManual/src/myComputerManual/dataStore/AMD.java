package myComputerManual.dataStore;

public class AMD extends Component {
    
    AMD()
    {
        setName("AMD");
        setDescription("AMD Athlon Processor 760K Richland");
        setPages(3);
        setListOfFigures(2);
        setGlossary("AMD Glossary");
    }
}


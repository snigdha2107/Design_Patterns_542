package myComputerManual.dataStore;

public class BluRay extends Component {
    
    BluRay()
    {
        setName("Bluray");
        setDescription("Samsung BD-R");
        setPages(4);
        setListOfFigures(3);
        setGlossary("bluray Glossary");
    }
}

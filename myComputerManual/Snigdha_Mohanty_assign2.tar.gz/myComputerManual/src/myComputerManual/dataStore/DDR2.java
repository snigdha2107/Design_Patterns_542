package myComputerManual.dataStore;

public class DDR2 extends Component {
	
    DDR2()
    {
        setName("DDR2");
        setDescription("4 GB DDR2 RAM");
        setPages(4);
        setListOfFigures(3);
        setGlossary("DDR2 Glossary");
    }
}

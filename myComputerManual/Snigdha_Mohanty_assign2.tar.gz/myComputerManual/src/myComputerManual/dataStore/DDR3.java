package myComputerManual.dataStore;

public class DDR3 extends Component {
    
    DDR3()
    {
        setName("DDR3");
        setDescription("8 GB DDR3 RAM");
        setPages(4);
        setListOfFigures(4);
        setGlossary("DDR3 Glossary");
    }
}

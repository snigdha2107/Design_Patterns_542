package myComputerManual.dataStore;

public class DVD extends Component {
    
    DVD()
    {
        setName("DVD");
        setDescription("Philips DVD+RW");
        setPages(5);
        setListOfFigures(5);
        setGlossary("DVD Glossary");
    }
}

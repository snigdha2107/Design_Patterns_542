package myComputerManual.dataStore;

public class GraphicsAMD extends Component {
    
    GraphicsAMD()
    {
        setName("ATI AMD");
        setDescription("GraphicsAMD AMD Radeon");
        setPages(6);
        setListOfFigures(6);
        setGlossary("GraphicsAMD Glossary");
    }
}

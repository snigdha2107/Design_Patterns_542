package myComputerManual.dataStore;

public class GraphicsNvidia extends Component {
    
    GraphicsNvidia()
    {
        setName("Nvidia");
        setDescription("GraphicsNvidia NVIDIA GeForce");
        setPages(7);
        setListOfFigures(7);
        setGlossary("GraphicsNvidia Glossary");
    }
}

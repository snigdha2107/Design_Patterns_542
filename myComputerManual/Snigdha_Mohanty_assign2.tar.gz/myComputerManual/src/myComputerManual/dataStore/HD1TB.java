package myComputerManual.dataStore;

public class HD1TB extends Component {
    
    HD1TB()
    {
        setName("HD1TB");
        setDescription("Samsung Electronics 840 EVO-Series 1TB");
        setPages(8);
        setListOfFigures(8);
        setGlossary("HD1TB Glossary");
    }
}

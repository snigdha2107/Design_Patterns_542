package myComputerManual.dataStore;

public class HD500gb extends Component {
    
    HD500gb()
    {
        setName("HD500GB");
        setDescription("Western Digital Bare Drives 500GB");
        setPages(9);
        setListOfFigures(9);
        setGlossary("HD500gb Glossary");
    }
}

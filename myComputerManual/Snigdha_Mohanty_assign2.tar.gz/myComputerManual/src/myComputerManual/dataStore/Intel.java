package myComputerManual.dataStore;

public class Intel extends Component {
	
    Intel()
    {
        setName("Intel");
        setDescription("Intel Core i7-4790 Processor");
        setPages(10);
        setListOfFigures(10);
        setGlossary("Intel Glossary");
    }
}

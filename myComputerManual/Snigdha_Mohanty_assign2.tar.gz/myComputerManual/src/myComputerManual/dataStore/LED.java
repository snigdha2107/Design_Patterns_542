package myComputerManual.dataStore;

public class LED extends Component {
    
    LED()
    {
        setName("LED");
        setDescription("Samsung WQHD 32-Inch");
        setPages(11);
        setListOfFigures(11);
        setGlossary("LED Glossary");
    }
}

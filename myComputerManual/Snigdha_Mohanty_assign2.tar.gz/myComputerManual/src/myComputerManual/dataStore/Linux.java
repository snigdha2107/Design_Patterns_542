package myComputerManual.dataStore;

public class Linux extends Component {
    
    Linux()
    {
        setName("LINUX");
        setDescription("Ubuntu Kylin");
        setPages(12);
        setListOfFigures(12);
        setGlossary("LINUX Glossary");
    }
}

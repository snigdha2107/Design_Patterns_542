package myComputerManual.dataStore;

public class SupportLifetime extends Component {
    
    SupportLifetime()
    {
        setName("Support Life Time");
        setDescription("SupportLifetime 5 Years Lifetime Support");
        setPages(13);
        setListOfFigures(13);
        setGlossary("SupportLifetime Glossary");
    }
}

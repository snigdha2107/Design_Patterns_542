package myComputerManual.dataStore;

public class SupportLimited extends Component {
    
    SupportLimited()
    {
        setName("Support Limited");
        setDescription("SupportLimited 2 Years Limited Support");
        setPages(14);
        setListOfFigures(14);
        setGlossary("SupportLimited Glossary");
    }
}

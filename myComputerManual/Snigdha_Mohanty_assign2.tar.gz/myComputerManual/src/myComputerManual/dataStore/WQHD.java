package myComputerManual.dataStore;

public class WQHD extends Component {
    
    WQHD()
    {
        setName("WQHD");
        setDescription("WQHD Asus 23.6-Inch Full-HD LED-Lit");
        setPages(16);
        setListOfFigures(16);
        setGlossary("WQHD Glossary");
    }
}

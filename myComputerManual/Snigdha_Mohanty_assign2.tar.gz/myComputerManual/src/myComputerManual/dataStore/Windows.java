package myComputerManual.dataStore;

public class Windows extends Component {
    
    Windows()
    {
        setName("Windows");
        setDescription("Windows 8");
        setPages(15);
        setListOfFigures(15);
        setGlossary("Windows Glossary");
    }
}
